<?php 
/*
Plugin Name: Bolby Elementor Elements
Plugin URI: https://themeforest.net/user/jthemes
Description: Bolby elements
Author: Jthemes
Author URI: http://jthemes.org
Version: 1.0.1
Text Domain: bolby
*/
include_once( 'loader.php' );